describe('Options', function() {
  it('should set timeout value', function() {
    assert(this.test._timeout === 1500);
  });
})