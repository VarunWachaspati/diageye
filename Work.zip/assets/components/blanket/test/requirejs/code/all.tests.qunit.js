﻿/// <reference path="require.js" />
/// <reference path="qunit.js" />

requirejs(['./tests/base/base.qunit.test',
           './tests/ui/ui.qunit.test'],
    function (){}
);
