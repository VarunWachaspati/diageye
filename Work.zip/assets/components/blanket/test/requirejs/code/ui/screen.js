﻿define(["base/core"], function(core) {
    return {
        displayVersion: "Version: " + core.version
    };
});