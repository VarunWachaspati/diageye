﻿define(function () {
    return {
        version: 8
    };
});