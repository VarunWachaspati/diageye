define(["require_sample"],function(){

test( "require test", function() {
  ok( sampleTest() == 10, "Passed!" );
});

});