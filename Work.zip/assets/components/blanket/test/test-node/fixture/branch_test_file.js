function BRANCHTEST(x){
return x === 1 ? true : false;
}