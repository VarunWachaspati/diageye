//this is test source
var test='1234';
if (test === '1234')
  console.log(true);
//comment
console.log(test);