var B = require("./sourceB");
var C = require("./sourceC");

module.exports = B + C;