require("./sourceB");

module.exports = 4;