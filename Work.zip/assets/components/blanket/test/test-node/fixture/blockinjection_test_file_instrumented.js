_$jscoverage['blockinjection_test_file.js'][1]++;
if(true)
  {
_$jscoverage['blockinjection_test_file.js'][2]++;
var a=true;}

else {
_$jscoverage['blockinjection_test_file.js'][3]++;
if(false)
  {
_$jscoverage['blockinjection_test_file.js'][4]++;
if (true)
    {
_$jscoverage['blockinjection_test_file.js'][5]++;
var b=false;}
}
}
