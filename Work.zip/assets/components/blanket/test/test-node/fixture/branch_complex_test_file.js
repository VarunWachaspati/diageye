function COMPLEXBRANCHTEST(x,y,z){
return x === 1 ? true : y === 2 ? z === 3 ? true : false : false;
}