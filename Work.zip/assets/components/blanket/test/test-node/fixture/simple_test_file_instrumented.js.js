//this is test source
_$jscoverage['simple_test_file.js'][2]++;
var test='1234';
_$jscoverage['simple_test_file.js'][3]++;
if (test === '1234')
  {
_$jscoverage['simple_test_file.js'][4]++;
console.log(true);}

//comment
_$jscoverage['simple_test_file.js'][6]++;
console.log(test);