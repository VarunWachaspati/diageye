if(true)
  var a=true;
else if(false)
  if (true)
    var b=false;