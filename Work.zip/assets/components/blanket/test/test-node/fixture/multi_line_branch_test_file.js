function MULTIBRANCHTEST(x){
return x === 1 ?
    true :
    false;
}