if (typeof _$jscoverage === 'undefined') _$jscoverage = {};
if (typeof _$jscoverage['simple_test_file.js'] === 'undefined'){_$jscoverage['simple_test_file.js']=[];
_$jscoverage['simple_test_file.js'].source=['//this is test source',
'var test=\'1234\';',
'if (test === \'1234\')',
'  console.log(true);',
'//comment',
'console.log(test);'];
_$jscoverage['simple_test_file.js'][2]=0;
_$jscoverage['simple_test_file.js'][3]=0;
_$jscoverage['simple_test_file.js'][4]=0;
_$jscoverage['simple_test_file.js'][6]=0;
}//this is test source
_$jscoverage['simple_test_file.js'][2]++;
var test='1234';
_$jscoverage['simple_test_file.js'][3]++;
if (test === '1234')
  {
_$jscoverage['simple_test_file.js'][4]++;
console.log(true);}

//comment
_$jscoverage['simple_test_file.js'][6]++;
console.log(test);