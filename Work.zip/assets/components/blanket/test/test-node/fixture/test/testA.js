var srcA = require("../src/sourceA");

module.exports = srcA;