// this is a comment
console.log("this should be instrumented.");
// this is another comment
console.log("this should also be instrumented");
/* longer comment */
console.log("another instrumented line.");
// a multiline
// comment
console.log("yet another");
/* another
   multiline
   comment
   */
console.log("final line");