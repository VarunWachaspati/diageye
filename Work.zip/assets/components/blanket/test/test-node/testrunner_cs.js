var blanket = require("../../src/index")();
blanket.options("filter","src/sample");

require("./tests/coffee-script/test.coffee");