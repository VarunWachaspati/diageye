YUI.add('test-module', function (Y) {
    Y.testModule = 5;
});