var url = require("url");

window.urlResult = url.parse("http://www.blanketjs.org").host;