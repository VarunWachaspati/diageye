test('object should  exist', function(){
    ok(window.testLibResult);
    ok(window.urlResult);
});