var lib = require("./testlib");

window.testLibResult = lib;