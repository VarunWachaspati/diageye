/*

From the Chutzpah test suite: http://chutzpah.codeplex.com/


*/
define(["base/core"], function(core) {
    return {
        displayVersion: "Version: " + core.version
    };
});