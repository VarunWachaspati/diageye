/*

From the Chutzpah test suite: http://chutzpah.codeplex.com/


*/
define(function () {
    return {
        version: 8
    };
});