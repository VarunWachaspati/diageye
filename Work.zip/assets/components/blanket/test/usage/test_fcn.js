function testfcn(){
    console.log("test");
}

$("#testheader").click(testfcn);