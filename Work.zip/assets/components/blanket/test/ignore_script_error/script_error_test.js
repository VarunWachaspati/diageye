test('object should not exist', function(){
    ok(typeof errorThing === 'undefined');
});