var errorThing = {
    thing: ["thing" + someUndefinedVariable]
};