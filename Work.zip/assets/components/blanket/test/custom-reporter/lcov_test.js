test( "sample test", function() {
  ok( sampleTest() == 10, "Passed!" );
});