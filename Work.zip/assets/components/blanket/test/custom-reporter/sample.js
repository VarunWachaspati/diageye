//this test should fail
var sampleTest = function(){
    return 10;
};