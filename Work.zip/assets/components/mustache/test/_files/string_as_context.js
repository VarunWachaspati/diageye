({
  a_string: 'aa',
  a_list: ['a','b','c']
})
